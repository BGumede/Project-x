function search(event) {
  event.preventDefault();
  let searchInputElement = document.querySelector("#search-input");
  let cityElement = document.querySelector("#current-city");
  let temperatureElement = document.querySelector("#current-temperature-value");
  let descriptionElement = document.querySelector("#weather-description");
  let humidityElement = document.querySelector("#humidity");
  let windSpeedElement = document.querySelector("#wind-speed");
  let city = searchInputElement.value;
  cityElement.innerHTML = city;
  let apiKey = "fa247bcfa03a460o3b03c39701d4cft5";
  let apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  axios
    .get(apiUrl)
    .then(function (response) {
      let temperature = response.data.main.temp;
      let weatherDescription = response.data.weather[0].description;
      let humidity = response.data.main.humidity;
      let windSpeed = response.data.wind.speed;
      temperatureElement.innerHTML = Math.round(temperature);
      descriptionElement.innerHTML = weatherDescription;
      humidityElement.innerHTML = humidity + "%";
      windSpeedElement.innerHTML = windSpeed + "km/h";
    })
    .catch(function (error) {
      console.error("Error fetching data: ", error);
      alert("City not found. Please try again.");
    });
}

let searchForm = document.querySelector("#search-form");
searchForm.addEventListener("submit", search);

function formatDate(date) {
  let minutes = date.getMinutes();
  let hours = date.getHours();
  let day = date.getDay();
  if (minutes < 10) {
    minutes = `0${minutes}`;
  }
  if (hours < 10) {
    hours = `0${hours}`;
  }
  let days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  let formattedDay = days[day];
  return `${formattedDay} ${hours}:${minutes}`;
}

let currentDateElement = document.querySelector("#current-date");
let currentDate = new Date();
currentDateElement.innerHTML = formatDate(currentDate);
